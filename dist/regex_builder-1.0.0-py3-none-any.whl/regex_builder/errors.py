class NotSection(Exception):
    pass
